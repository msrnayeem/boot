package com.visa.VisaServices_SpringBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VisaServicesSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
